package com.example.licenta;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatSpinner;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.material.datepicker.MaterialDatePicker;
import com.parse.ParseException;
import com.parse.ParseUser;
import com.parse.SignUpCallback;

import java.time.LocalDate;
import java.time.Period;
import java.util.Calendar;
import java.util.Date;
import java.util.Objects;

public class SignupActivity extends AppCompatActivity {

    com.google.android.material.textfield.TextInputEditText emailSignupTextEdit,
            passSignupTextEdit, confirmPassTextEdit, nameTextEdit, surnameTextEdit,
            phoneTextEdit;
    DatePicker birthdayPicker;
    AppCompatSpinner genderSpinner;
    AppCompatSpinner bloodTypeSpinner;
    com.google.android.material.checkbox.MaterialCheckBox isDonorCheckBox;
    private Activity LoginActivity; // !!!!!!!!!!!!!!!

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        // Assignments
        emailSignupTextEdit = findViewById(R.id.emailSignupTextEdit);
        passSignupTextEdit = findViewById(R.id.passSignupTextEdit);
        confirmPassTextEdit = findViewById(R.id.confirmPassTextEdit);
        nameTextEdit = findViewById(R.id.nameTextEdit);
        surnameTextEdit = findViewById(R.id.surnameTextEdit);
        phoneTextEdit = findViewById(R.id.phoneTextEdit);
        birthdayPicker = findViewById(R.id.birthdatePicker);
        genderSpinner = findViewById(R.id.genderSpinner);
        isDonorCheckBox = findViewById(R.id.isDonorCheckBox);
        bloodTypeSpinner = findViewById(R.id.bloodTypeSpinner);

        // For gender spinner
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.genders_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        genderSpinner.setAdapter(adapter);

        // For blood type spinner
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this,
                R.array.blood_types_array, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        bloodTypeSpinner.setAdapter(adapter2);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void signup(View view) {
        try {
            final String userEmail = Objects.requireNonNull(emailSignupTextEdit.getText()).toString();
            final String password = Objects.requireNonNull(passSignupTextEdit.getText()).toString();
            final String confirmedPassword = Objects.requireNonNull(confirmPassTextEdit.getText()).toString();
            final String name = Objects.requireNonNull(nameTextEdit.getText()).toString();
            final String surname = Objects.requireNonNull(surnameTextEdit.getText()).toString();
            final String gender = genderSpinner.getSelectedItem().toString();
            final String bloodType = bloodTypeSpinner.getSelectedItem().toString();
            int age;
            boolean isDonor;


            if (!isEmailValid(userEmail))
                emailSignupTextEdit.setError("Format incorect.");
            else
                emailSignupTextEdit.setError(null);

            if (!isPasswordValid(password))
                passSignupTextEdit.setError("Parola trebuie sa aiba cel putin 8 caractere.");
            else
                passSignupTextEdit.setError(null);

            // Sign up with Parse
            ParseUser user = new ParseUser();

             //user.setUsername( < Insert Username Here>);

            // If passwords match, set user password
            if (!password.equals(confirmedPassword)) {
                confirmPassTextEdit.setError("Parolele nu corespund.");
            } else
                user.setPassword(password);

            // Set user email
            user.setEmail(emailSignupTextEdit.getText().toString());
            // Set user name
            if (!(name.length() >= 1))
                nameTextEdit.setError("Acest camp este obligatoriu.");
            else
                user.put("name", name);

            // Set user surname
            if (!(surname.length() >= 1))
                nameTextEdit.setError("Acest camp este obligatoriu.");
            else
                user.put("surname", surname);

            // Set user gender
            user.put("gender", gender);

            // Set user age
            age = getUserAgeFromBirthday();
            user.put("age", age);

            //Set user blood type
            user.put("bloodType", bloodType);

            // Set user "isDonor" field
            if (isDonorCheckBox.isChecked())
                user.put("isDonor", true);
            else
                user.put("isDonor", false);


            user.signUpInBackground(new SignUpCallback() {
                @Override
                public void done(ParseException e) {
                    if (e == null) {
                        ParseUser.logOut();
                        alertDisplayer("Account Created Successfully!", "Please verify your email before Login", false);
                    } else {
                        ParseUser.logOut();
                        alertDisplayer("Error Account Creation failed", "Account could not be created" + " :" + e.getMessage(), true);
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void alertDisplayer(String title,String message, final boolean error){
        AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        if(!error) {
                            Intent intent = new Intent(SignupActivity.this, LoginActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        }
                    }
                });
        AlertDialog ok = builder.create();
        ok.show();
    }

    // Check if email is a valid format
    public boolean isEmailValid(CharSequence email) {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    // Check is password is at least 8 characters long
    public boolean isPasswordValid(String password) {
        return password.length() >= 8;
    }

    // Returns user age
    // Vezi parsare, LocalDate, Calendar, cum au datele reprezentate (7 iunie sau 07 iunie de exemplu)
    @RequiresApi(api = Build.VERSION_CODES.O)
    public int getUserAgeFromBirthday() throws java.text.ParseException{
        // Calculate age of user, using his birthday;

        Calendar calendar = getDateFromDatePicker(birthdayPicker);

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        LocalDate today = LocalDate.now();
        LocalDate birthday = LocalDate.of(year, month, day);

        Period period = Period.between(birthday, today);

        return period.getYears();
    }

    // Returns a calendar with the birthday picked by the user
    public static Calendar getDateFromDatePicker(DatePicker birthdayPicker){
        int day = birthdayPicker.getDayOfMonth();
        int month = birthdayPicker.getMonth();
        int year =  birthdayPicker.getYear();

        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, day);

        return calendar;
    }
}



